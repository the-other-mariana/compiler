#include <stdio.h>

int main() {
    float monica_buffer2=20.37;
    for(int i=0;i<=10; i++){
        printf("value: %d", monica_buffer2);
    }
    int hola = 23,
    return 0;
}
